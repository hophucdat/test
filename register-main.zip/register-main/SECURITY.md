# Security Policy

## Reporting a vulnerability
You can report low severity bugs as [issues](https://github.com/is-a-dev/register/issues/new/choose) on this repository.

However, for **higher severity vulnerabilities and bugs**, please email security@is-a.dev.
