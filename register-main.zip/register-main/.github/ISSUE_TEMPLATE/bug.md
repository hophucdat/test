---
name: bug
about: Use this template to report any bugs you've encountered related to the project
title: 'What bug did you encounter?'
labels: bug

---

### Your subdomain

### Expected outcome

### Observed outcome
