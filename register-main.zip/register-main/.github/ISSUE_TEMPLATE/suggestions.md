---
name: suggestion
about: Use this template for feedbacks and suggestions
title: 'Feedback/suggestion'
labels: suggestion

---

### What do you want added?
