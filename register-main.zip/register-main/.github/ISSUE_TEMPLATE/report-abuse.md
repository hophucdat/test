---
name: report-abuse
about: Use this template to report abusive domains
title: 'Report abuse'
labels: report-abuse

---

### Domain

### Reason
<!-- Explain why you think this domain is being abused -->

### Proof
<!-- Proof of the domain being abused -->
